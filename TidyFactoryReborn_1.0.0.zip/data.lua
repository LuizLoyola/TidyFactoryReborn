require ("prototypes/electric-pole")
